public class Pistol : Weapon
{
   
}
